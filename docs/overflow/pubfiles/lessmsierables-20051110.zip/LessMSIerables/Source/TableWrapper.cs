using System;
using System.Collections;
using System.Collections.Specialized;
using System.Diagnostics;
using Microsoft.Tools.WindowsInstallerXml.Msi;

namespace Willeke.Scott.LessMSIerables
{
	/// <summary>
	/// Represents a generic row in a table.
	/// </summary>
	public class TableRow
	{
		private readonly IDictionary _columns;

		private TableRow(IDictionary columns)
		{
			if (columns == null)
				throw new ArgumentNullException("columns");
			_columns = columns;
		}

		public static TableRow[] GetRowsFromTable(Database msidb, string tableName)
		{
			if (!msidb.TableExists(tableName))
			{
				Trace.WriteLine(string.Format("Table name does {0} not exist Found.", tableName));
				return new TableRow[0];
			}

			string query = string.Concat("SELECT * FROM `", tableName, "`");
			using (ViewWrapper view = new ViewWrapper(msidb.OpenExecuteView(query)))
			{
				ArrayList /*<TableRow>*/ rows = new ArrayList(view.Records.Count);

				ColumnInfo[] columns = view.Columns;
				foreach (object[] values in view.Records)
				{
					HybridDictionary valueCollection = new HybridDictionary(values.Length);
					for (int cIndex = 0; cIndex < columns.Length; cIndex++)
					{
						valueCollection[columns[cIndex].Name] = values[cIndex];
					}
					rows.Add(new TableRow(valueCollection));
				}
				return (TableRow[]) rows.ToArray(typeof(TableRow));
			}
		}

		public string GetString(string columnName)
		{
			return Convert.ToString(GetValue(columnName));
		}
		public object GetValue(string columnName)
		{
			return _columns[columnName];
		}

		public Int32 GetInt32(string columnName)
		{
			return Convert.ToInt32(GetValue(columnName));
		}
	}
}