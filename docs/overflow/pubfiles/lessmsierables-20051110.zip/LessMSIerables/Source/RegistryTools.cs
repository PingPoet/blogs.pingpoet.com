using Microsoft.Win32;

namespace Willeke.Scott.LessMSIerables
{
	internal class RegistryTool
	{
		public static void RegisterShortcutmenu()
		{
			RegistryKey extractKey = Registry.ClassesRoot.CreateSubKey(@"Msi.Package\shell\Extract");
			extractKey.SetValue("", "&Extract Files");
			RegistryKey command = extractKey.CreateSubKey("command");

			string expectedValue = '\"' + GetExePath() + "\" /x \"%1\" \"%1_extracted\"";
			string cmd = command.GetValue("") as string;
			if (cmd != null && cmd.StartsWith(expectedValue))
				return;

			command.SetValue("", expectedValue);
		}

		static string GetExePath()
		{
			return typeof (RegistryTool).Module.FullyQualifiedName;
		}
	}
}
