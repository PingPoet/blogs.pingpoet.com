/*
Scott Willeke - 2004
http://scott.willeke.com 
Consider this code licensed under Common Public License Version 1.0 (http://www.opensource.org/licenses/cpl1.0.txt).
*/
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Windows.Forms;
using Microsoft.Tools.WindowsInstallerXml.Msi;
using Willeke.Shared.Windows.Forms;

namespace Willeke.Scott.LessMSIerables
{
	internal class MainForm : Form
	{
		public MainForm(string defaultInputFile)
		{
			InitializeComponent();
			MsiFileListViewItem.InitListViewColumns(fileList);
			PropertyInfo.InitListViewColumns(this.propertiesList);
			if (defaultInputFile != null && defaultInputFile.Length > 0)
				this.txtMsiFileName.Text = defaultInputFile;
		}

		#region UI Event Handlers

		private void btnBrowse_Click(object sender, EventArgs e)
		{
			if (DialogResult.OK != this.openMsiDialog.ShowDialog(this))
				return;
			this.txtMsiFileName.Text = this.openMsiDialog.FileName;
			LoadCurrentFile();
		}

		private void ReloadCurrentUIOnEnterKeyPress(object sender, KeyPressEventArgs e)
		{
			if (e.KeyChar == (char) 13)
			{
				e.Handled = true;
				LoadCurrentFile();
			}
		}


		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
			ViewTable();
		}

		private void btnExtract_Click(object sender, EventArgs e)
		{
			ArrayList /*<MsiFile>*/ selectedFiles = new ArrayList();
			if (this.fileList.SelectedItems.Count == 0)
				return;

			if (this.folderBrowser.SelectedPath == null || folderBrowser.SelectedPath.Length <= 0)
				this.folderBrowser.SelectedPath = this.GetSelectedMsiFile().DirectoryName;

			if (DialogResult.OK != this.folderBrowser.ShowDialog(this))
				return;

			this.btnExtract.Enabled = false;
			ExtractionProgressDialog progressDialog = new ExtractionProgressDialog(this);
			progressDialog.Show();
			progressDialog.Update();
			try
			{
				DirectoryInfo outputDir = new DirectoryInfo(this.folderBrowser.SelectedPath);
				foreach (MsiFileListViewItem item in this.fileList.Items)
				{
					if (item.Checked)
						selectedFiles.Add(item._file);
				}

				FileInfo msiFile = GetSelectedMsiFile();
				if (msiFile == null)
					return;
				MsiFile[] filesToExtract = (MsiFile[]) selectedFiles.ToArray(typeof (MsiFile));
				Wixtracts.ExtractFiles(msiFile, outputDir, filesToExtract, new AsyncCallback(progressDialog.UpdateProgress));
			}
			finally
			{
				progressDialog.Close();
				progressDialog.Dispose();
				this.btnExtract.Enabled = true;
			}
		}

		private class ExtractionProgressDialog : Form
		{
			private ProgressBar _progressBar;
			private Label _label;

			public ExtractionProgressDialog(Form owner)
			{
				this.Owner = owner;

				this.ShowInTaskbar = false;
				this.TopMost = true;
				this.Size = new Size(320, 125);
				this.ControlBox = false;
				this.MaximizeBox = false;
				this.MinimizeBox = false;
				this.FormBorderStyle = FormBorderStyle.FixedDialog;
				this.StartPosition = FormStartPosition.Manual;

				this.Top = owner.Top + ((owner.Height - this.Height)/2);
				this.Left = owner.Left + ((owner.Width - this.Width)/2);

				this.DockPadding.Left = this.DockPadding.Right = 10;
				this.DockPadding.Top = this.DockPadding.Bottom = 10;

				_label = new Label();
				_label.Text = "";
				_label.Dock = DockStyle.Top;
				this.Controls.Add(_label);

				_progressBar = new ProgressBar();
				_progressBar.Dock = DockStyle.Top;
				_progressBar.Value = 0;
				this.Controls.Add(_progressBar);
			}

			public void UpdateProgress(IAsyncResult result)
			{
				if (result is Wixtracts.ExtractionProgress)
					UpdateProgress((Wixtracts.ExtractionProgress) result);
			}

			private delegate void UpdateProgressHandler(Wixtracts.ExtractionProgress progress);

			public void UpdateProgress(Wixtracts.ExtractionProgress progress)
			{
				if (this.InvokeRequired)
				{
					// This is ahack, but should be okay if needed to get around invoke
					this.Invoke(new UpdateProgressHandler(this.UpdateProgress), new object[] {progress});
					return;
				}

				_progressBar.Minimum = 0;
				_progressBar.Maximum = progress.TotalFileCount;
				_progressBar.Value = progress.FilesExtractedSoFar;
				string details;
				if (progress.Activity == Wixtracts.ExtractionActivity.ExtractingFile)
					details = "Extracting file '" + progress.CurrentFileName + "'";
				else
					details = Enum.GetName(typeof (Wixtracts.ExtractionActivity), progress.Activity);

				_label.Text = string.Format("Extracting ({0})...", details);
				this.Invalidate(true);
				this.Update();
			}
		}


		private void ChangeUiEnabled(bool doEnable)
		{
			this.btnExtract.Enabled = doEnable;
			this.cboTable.Enabled = doEnable;
		}

		#endregion

		private void LoadCurrentFile()
		{
			bool isBadFile = false;
			try
			{
				ViewSummary();
				LoadTables();
				ViewFiles();
				ViewTable();
			}
			catch (Exception eCatchAll)
			{
				isBadFile = true;
				Error("Failed to open file.", eCatchAll);
			}
			ChangeUiEnabled(!isBadFile);
		}

		private void LoadTables()
		{
			this.cboTable.Items.Clear();
			this.cboTable.Items.AddRange(new object[]
				{
					"File",
					"Media",
					"Shortcut",
					"Property",
					"AppSearch            ",
					"RegLocator",
					"CompLocator",
					"DrLocator",
					"Signature",
					"LaunchCondition",
					"Condition",
					"FeatureComponents",
					"Class",
					"ProgId",
					"Extension",
					"Feature",
					"Directory",
					"Environment",
					"MsiAssembly",
					"RemoveFile",
					"ReserveCost",
					"Shortcut",
					"Component",
					"File",
					"CreateFolder",
					"Upgrade",
					"ServiceControl",
					"ServiceInstall",
					"LockPermissions",
					"Media",
					"CustomAction",
					"UIText",
					"TextStyle",
					"Dialog",
					"Control",
					"ActionText",
					"Error",
					"ModuleSignature",
					"Component"
				});
		}


		/// <summary>
		/// Updates the ui with the currently selected msi file.
		/// </summary>
		private void ViewFiles()
		{
			using (Database msidb = new Database(GetSelectedMsiFile().FullName, OpenDatabase.ReadOnly))
			{
				ViewFiles(msidb);
			}
		}

		/// <summary>
		/// Displays the list of files in the extract tab.
		/// </summary>
		/// <param name="msidb">The msi database.</param>
		private void ViewFiles(Database msidb)
		{
			if (msidb == null)
				return;

			using (new DisposableCursor(this))
			{
				//used to filter and sort columns
				Hashtable /*<string, int>*/ columnMap = new Hashtable(CaseInsensitiveHashCodeProvider.DefaultInvariant, CaseInsensitiveComparer.DefaultInvariant);
				columnMap.Add("FileName", 0);
				columnMap.Add("FileSize", 1);
				columnMap.Add("Version", 2);
				columnMap.Add("Language", 3);
				columnMap.Add("Attributes", 4);

				try
				{
					this.statusPanelDefault.Text = "";
					fileList.Items.Clear();

					foreach (MsiFile msiFile in MsiFile.CreateMsiFilesFromMSI(msidb))
						fileList.Items.Add(new MsiFileListViewItem(msiFile));
					statusPanelFileCount.Text = string.Concat(fileList.Items.Count, " files found.");
				}
				catch (Exception eUnexpected)
				{
					Error(string.Concat("Cannot view files:", eUnexpected.Message), eUnexpected);
				}
			}
		}


		private void ViewTable()
		{
			using (Database msidb = new Database(GetSelectedMsiFile().FullName, OpenDatabase.ReadOnly))
			{
				string tableName = this.cboTable.Text;
				ViewTable(msidb, tableName);
			}
		}


		/// <summary>
		/// Shows the table in the list on the view table tab.
		/// </summary>
		/// <param name="msidb">The msi database.</param>
		/// <param name="tableName">The name of the table.</param>
		private void ViewTable(Database msidb, string tableName)
		{
			if (msidb == null || tableName == null && tableName.Length == 0)
				return;

			Status(string.Concat("Processing Table \'", tableName, "\'."));

			using (new DisposableCursor(this))
			{
				try
				{
					tableList.Clear();
					if (!msidb.TableExists(tableName))
					{
						Error("Table \'" + tableName + "' does not exist.", null);
						return;
					}

					string query = string.Concat("SELECT * FROM `", tableName, "`");

					using (ViewWrapper view = new ViewWrapper(msidb.OpenExecuteView(query)))
					{
						int colWidth = this.tableList.ClientRectangle.Width/view.Columns.Length;
						foreach (ColumnInfo col in view.Columns)
						{
							ColumnHeader header = new ColumnHeader();
							header.Text = string.Concat(col.Name, " (", col.TypeID, ")");
							header.Width = colWidth;
							tableList.Columns.Add(header);
						}

						foreach (object[] values in view.Records)
						{
							ListViewItem item = new ListViewItem(Convert.ToString(values[0]));
							for (int colIndex = 1; colIndex < values.Length; colIndex++)
								item.SubItems.Add(Convert.ToString(values[colIndex]));
							tableList.Items.Add(item);
						}
					}
					Status("Idle");
				}
				catch (Exception eUnexpected)
				{
					Error(string.Concat("Cannot view table:", eUnexpected.Message), eUnexpected);
				}
			}

		}


		private FileInfo GetSelectedMsiFile()
		{
			FileInfo file = new FileInfo(this.txtMsiFileName.Text);
			if (!file.Exists)
			{
				Error(string.Concat("File \'", file.FullName, "\' does not exist."), null);
				return null;
			}
			return file;
		}

		private class MsiFileListViewItem : ListViewItem
		{
			public MsiFile _file;

			public static void InitListViewColumns(ListView lv)
			{
				lv.Columns.Add("File Name", 200, HorizontalAlignment.Left);
				lv.Columns.Add("Directory", 225, HorizontalAlignment.Left);
				lv.Columns.Add("Size", 60, HorizontalAlignment.Left);
				lv.Columns.Add("Version", 60, HorizontalAlignment.Left);
				lv.AllowColumnReorder = true;
			}

			public MsiFileListViewItem(MsiFile file)
			{
				this.Checked = true;
				_file = file;
				this.Text = file.LongFileName;
				string path = file.Directory != null ? file.Directory.GetPath() : "";
				this.SubItems.Add(path);
				this.SubItems.Add(Convert.ToString(file.FileSize));
				this.SubItems.Add(Convert.ToString(file.Version));
			}

			public override string ToString()
			{
				return _file.LongFileName;
			}
		}

		#region Status Stuff

		private void Status(string msg)
		{
			this.statusPanelDefault.Text = "Status:" + msg;
		}

		private void Error(string msg, Exception exception)
		{
			this.statusPanelDefault.Text = "ERROR:" + msg;
			if (exception != null)
				this.statusPanelDefault.ToolTipText = exception.ToString();
			else
				this.statusPanelDefault.ToolTipText = "";

		}

		#endregion	

		private StatusBar statusBar1;
		private StatusBarPanel statusPanelDefault;
		private StatusBarPanel statusPanelFileCount;
		private Button btnSelectAll;
		private Button btnUnselectAll;
		private TabPage tabSummary;
		private TextBox txtSummaryDescription;
		private GroupBox grpDescription;
		private Panel panel2;
		private ListView propertiesList;

		#region Designer Stuff

		/// <summary>
		/// Required designer variable.
		/// </summary>
		private IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtMsiFileName = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.btnBrowse = new System.Windows.Forms.Button();
			this.tabs = new System.Windows.Forms.TabControl();
			this.tabExtractFiles = new System.Windows.Forms.TabPage();
			this.fileList = new System.Windows.Forms.ListView();
			this.panel2 = new System.Windows.Forms.Panel();
			this.btnSelectAll = new System.Windows.Forms.Button();
			this.btnUnselectAll = new System.Windows.Forms.Button();
			this.btnExtract = new System.Windows.Forms.Button();
			this.tabTableView = new System.Windows.Forms.TabPage();
			this.cboTable = new System.Windows.Forms.ComboBox();
			this.tableList = new System.Windows.Forms.ListView();
			this.label2 = new System.Windows.Forms.Label();
			this.tabSummary = new System.Windows.Forms.TabPage();
			this.propertiesList = new System.Windows.Forms.ListView();
			this.grpDescription = new System.Windows.Forms.GroupBox();
			this.txtSummaryDescription = new System.Windows.Forms.TextBox();
			this.panel1 = new System.Windows.Forms.Panel();
			this.folderBrowser = new System.Windows.Forms.FolderBrowserDialog();
			this.openMsiDialog = new System.Windows.Forms.OpenFileDialog();
			this.statusBar1 = new System.Windows.Forms.StatusBar();
			this.statusPanelDefault = new System.Windows.Forms.StatusBarPanel();
			this.statusPanelFileCount = new System.Windows.Forms.StatusBarPanel();
			this.tabs.SuspendLayout();
			this.tabExtractFiles.SuspendLayout();
			this.panel2.SuspendLayout();
			this.tabTableView.SuspendLayout();
			this.tabSummary.SuspendLayout();
			this.grpDescription.SuspendLayout();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.statusPanelDefault)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.statusPanelFileCount)).BeginInit();
			this.SuspendLayout();
			// 
			// txtMsiFileName
			// 
			this.txtMsiFileName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.txtMsiFileName.Location = new System.Drawing.Point(46, 4);
			this.txtMsiFileName.Name = "txtMsiFileName";
			this.txtMsiFileName.Size = new System.Drawing.Size(247, 20);
			this.txtMsiFileName.TabIndex = 0;
			this.txtMsiFileName.Text = "";
			this.txtMsiFileName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ReloadCurrentUIOnEnterKeyPress);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(10, 7);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(26, 16);
			this.label1.TabIndex = 1;
			this.label1.Text = "&File:";
			// 
			// btnBrowse
			// 
			this.btnBrowse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.btnBrowse.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnBrowse.Location = new System.Drawing.Point(300, 7);
			this.btnBrowse.Name = "btnBrowse";
			this.btnBrowse.Size = new System.Drawing.Size(20, 17);
			this.btnBrowse.TabIndex = 1;
			this.btnBrowse.Text = "...";
			this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
			// 
			// tabs
			// 
			this.tabs.Controls.Add(this.tabExtractFiles);
			this.tabs.Controls.Add(this.tabTableView);
			this.tabs.Controls.Add(this.tabSummary);
			this.tabs.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tabs.Location = new System.Drawing.Point(0, 27);
			this.tabs.Name = "tabs";
			this.tabs.SelectedIndex = 0;
			this.tabs.Size = new System.Drawing.Size(336, 323);
			this.tabs.TabIndex = 0;
			// 
			// tabExtractFiles
			// 
			this.tabExtractFiles.Controls.Add(this.fileList);
			this.tabExtractFiles.Controls.Add(this.panel2);
			this.tabExtractFiles.DockPadding.All = 5;
			this.tabExtractFiles.Location = new System.Drawing.Point(4, 22);
			this.tabExtractFiles.Name = "tabExtractFiles";
			this.tabExtractFiles.Size = new System.Drawing.Size(328, 297);
			this.tabExtractFiles.TabIndex = 0;
			this.tabExtractFiles.Text = "Extract Files";
			// 
			// fileList
			// 
			this.fileList.AllowColumnReorder = true;
			this.fileList.CheckBoxes = true;
			this.fileList.Dock = System.Windows.Forms.DockStyle.Fill;
			this.fileList.FullRowSelect = true;
			this.fileList.GridLines = true;
			this.fileList.LabelWrap = false;
			this.fileList.Location = new System.Drawing.Point(5, 5);
			this.fileList.Name = "fileList";
			this.fileList.Size = new System.Drawing.Size(318, 255);
			this.fileList.TabIndex = 0;
			this.fileList.View = System.Windows.Forms.View.Details;
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.btnSelectAll);
			this.panel2.Controls.Add(this.btnUnselectAll);
			this.panel2.Controls.Add(this.btnExtract);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel2.Location = new System.Drawing.Point(5, 260);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(318, 32);
			this.panel2.TabIndex = 4;
			// 
			// btnSelectAll
			// 
			this.btnSelectAll.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnSelectAll.Location = new System.Drawing.Point(0, 8);
			this.btnSelectAll.Name = "btnSelectAll";
			this.btnSelectAll.TabIndex = 1;
			this.btnSelectAll.Text = "Select &All";
			this.btnSelectAll.Click += new System.EventHandler(this.btnSelectAll_Click);
			// 
			// btnUnselectAll
			// 
			this.btnUnselectAll.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnUnselectAll.Location = new System.Drawing.Point(88, 8);
			this.btnUnselectAll.Name = "btnUnselectAll";
			this.btnUnselectAll.TabIndex = 2;
			this.btnUnselectAll.Text = "&Unselect All";
			this.btnUnselectAll.Click += new System.EventHandler(this.btnUnselectAll_Click);
			// 
			// btnExtract
			// 
			this.btnExtract.Enabled = false;
			this.btnExtract.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btnExtract.Location = new System.Drawing.Point(241, 8);
			this.btnExtract.Name = "btnExtract";
			this.btnExtract.TabIndex = 3;
			this.btnExtract.Text = "E&xtract";
			this.btnExtract.Click += new System.EventHandler(this.btnExtract_Click);
			// 
			// tabTableView
			// 
			this.tabTableView.Controls.Add(this.cboTable);
			this.tabTableView.Controls.Add(this.tableList);
			this.tabTableView.Controls.Add(this.label2);
			this.tabTableView.Location = new System.Drawing.Point(4, 22);
			this.tabTableView.Name = "tabTableView";
			this.tabTableView.Size = new System.Drawing.Size(328, 297);
			this.tabTableView.TabIndex = 1;
			this.tabTableView.Text = "Table View";
			// 
			// cboTable
			// 
			this.cboTable.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.cboTable.Enabled = false;
			this.cboTable.Location = new System.Drawing.Point(48, 7);
			this.cboTable.Name = "cboTable";
			this.cboTable.Size = new System.Drawing.Size(271, 20);
			this.cboTable.TabIndex = 8;
			this.cboTable.Text = "File";
			this.cboTable.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ReloadCurrentUIOnEnterKeyPress);
			this.cboTable.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
			// 
			// tableList
			// 
			this.tableList.AllowColumnReorder = true;
			this.tableList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.tableList.FullRowSelect = true;
			this.tableList.GridLines = true;
			this.tableList.LabelWrap = false;
			this.tableList.Location = new System.Drawing.Point(9, 35);
			this.tableList.Name = "tableList";
			this.tableList.Size = new System.Drawing.Size(310, 256);
			this.tableList.TabIndex = 7;
			this.tableList.View = System.Windows.Forms.View.Details;
			// 
			// label2
			// 
			this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(9, 10);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(33, 16);
			this.label2.TabIndex = 9;
			this.label2.Text = "&Table";
			// 
			// tabSummary
			// 
			this.tabSummary.Controls.Add(this.propertiesList);
			this.tabSummary.Controls.Add(this.grpDescription);
			this.tabSummary.DockPadding.All = 5;
			this.tabSummary.Location = new System.Drawing.Point(4, 22);
			this.tabSummary.Name = "tabSummary";
			this.tabSummary.Size = new System.Drawing.Size(328, 297);
			this.tabSummary.TabIndex = 2;
			this.tabSummary.Text = "Summary";
			// 
			// propertiesList
			// 
			this.propertiesList.Dock = System.Windows.Forms.DockStyle.Fill;
			this.propertiesList.FullRowSelect = true;
			this.propertiesList.GridLines = true;
			this.propertiesList.HideSelection = false;
			this.propertiesList.Location = new System.Drawing.Point(5, 5);
			this.propertiesList.Name = "propertiesList";
			this.propertiesList.Size = new System.Drawing.Size(318, 195);
			this.propertiesList.TabIndex = 2;
			this.propertiesList.View = System.Windows.Forms.View.Details;
			this.propertiesList.SelectedIndexChanged += new System.EventHandler(this.lstSummaryProperties_SelectedIndexChanged);
			// 
			// grpDescription
			// 
			this.grpDescription.Controls.Add(this.txtSummaryDescription);
			this.grpDescription.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.grpDescription.Location = new System.Drawing.Point(5, 200);
			this.grpDescription.Name = "grpDescription";
			this.grpDescription.Size = new System.Drawing.Size(318, 92);
			this.grpDescription.TabIndex = 2;
			this.grpDescription.TabStop = false;
			this.grpDescription.Text = "Description:";
			// 
			// txtSummaryDescription
			// 
			this.txtSummaryDescription.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.txtSummaryDescription.Dock = System.Windows.Forms.DockStyle.Fill;
			this.txtSummaryDescription.Location = new System.Drawing.Point(3, 16);
			this.txtSummaryDescription.Multiline = true;
			this.txtSummaryDescription.Name = "txtSummaryDescription";
			this.txtSummaryDescription.ReadOnly = true;
			this.txtSummaryDescription.Size = new System.Drawing.Size(312, 73);
			this.txtSummaryDescription.TabIndex = 1;
			this.txtSummaryDescription.Text = "";
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.txtMsiFileName);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Controls.Add(this.btnBrowse);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(336, 27);
			this.panel1.TabIndex = 0;
			// 
			// openMsiDialog
			// 
			this.openMsiDialog.DefaultExt = "msi";
			this.openMsiDialog.Filter = "msierablefiles|*.msi|All Files|*.*";
			// 
			// statusBar1
			// 
			this.statusBar1.Location = new System.Drawing.Point(0, 350);
			this.statusBar1.Name = "statusBar1";
			this.statusBar1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																						  this.statusPanelDefault,
																						  this.statusPanelFileCount});
			this.statusBar1.ShowPanels = true;
			this.statusBar1.Size = new System.Drawing.Size(336, 16);
			this.statusBar1.TabIndex = 2;
			// 
			// statusPanelDefault
			// 
			this.statusPanelDefault.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring;
			this.statusPanelDefault.Width = 210;
			// 
			// statusPanelFileCount
			// 
			this.statusPanelFileCount.Width = 110;
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(336, 366);
			this.Controls.Add(this.tabs);
			this.Controls.Add(this.statusBar1);
			this.Controls.Add(this.panel1);
			this.MinimumSize = new System.Drawing.Size(272, 184);
			this.Name = "MainForm";
			this.Text = "Less MSIérables";
			this.tabs.ResumeLayout(false);
			this.tabExtractFiles.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.tabTableView.ResumeLayout(false);
			this.tabSummary.ResumeLayout(false);
			this.grpDescription.ResumeLayout(false);
			this.panel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.statusPanelDefault)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.statusPanelFileCount)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private TextBox txtMsiFileName;
		private Label label1;
		private Button btnBrowse;
		private TabControl tabs;
		private TabPage tabExtractFiles;
		private TabPage tabTableView;
		private ComboBox cboTable;
		private ListView tableList;
		private Label label2;
		private Panel panel1;
		private ListView fileList;
		private Button btnExtract;
		private FolderBrowserDialog folderBrowser;
		private OpenFileDialog openMsiDialog;

		#endregion

		private void btnSelectAll_Click(object sender, EventArgs e)
		{
			ToggleSelectAllFiles(true);
		}

		private void btnUnselectAll_Click(object sender, EventArgs e)
		{
			ToggleSelectAllFiles(false);
		}

		/// <summary>
		/// Selects or unselects all files in the file list.
		/// </summary>
		/// <param name="doSelect">True to select the files, false to unselect them.</param>
		private void ToggleSelectAllFiles(bool doSelect)
		{
			this.fileList.BeginUpdate();
			try
			{
				foreach (ListViewItem item in this.fileList.Items)
				{
					item.Checked = doSelect;
				}
			}
			finally
			{
				fileList.EndUpdate();
			}
		}

		/// <summary>
		/// Updates the ui with the currently selected msi file.
		/// </summary>
		private void ViewSummary()
		{
			this.propertiesList.Items.Clear();
			try
			{
				using (Database msidb = new Database(GetSelectedMsiFile().FullName, OpenDatabase.ReadOnly))
				{
					foreach (PropertyInfo prop in PropertyInfo.GetPropertiesFromDatabase(msidb))
					{
						this.propertiesList.Items.Add(prop);
					}
				}
			}
			catch (Exception eUnexpected)
			{
				Error("Error loading Summary Information", eUnexpected);
			}
		}

		private void lstSummaryProperties_SelectedIndexChanged(object sender, EventArgs e)
		{
			if (propertiesList.SelectedItems.Count > 0)
			{
				PropertyInfo info = propertiesList.SelectedItems[0] as PropertyInfo;
				if (info != null)
					this.txtSummaryDescription.Text = info.Description;
			}
		}

		private class PropertyInfo : ListViewItem
		{
			private string _name;
			private int _pid;
			private VT _propertyType;
			private string _description;
			private object _value;

			#region msdn doc

			//http://msdn.microsoft.com/library/default.asp?url=/library/en-us/msi/setup/summary_information_stream_property_set.asp
			//Codepage 	PID_CODEPAGE 	1 	VT_I2
			//Title 	PID_TITLE 	2 	VT_LPSTR
			//Subject 	PID_SUBJECT 	3 	VT_LPSTR
			//Author 	PID_AUTHOR 	4 	VT_LPSTR
			//Keywords 	PID_KEYWORDS 	5 	VT_LPSTR
			//Comments 	PID_COMMENTS 	6 	VT_LPSTR
			//Template 	PID_TEMPLATE 	7 	VT_LPSTR
			//Last Saved By 	PID_LASTAUTHOR 	8 	VT_LPSTR
			//Revision Number 	PID_REVNUMBER 	9 	VT_LPSTR
			//Last Printed 	PID_LASTPRINTED 	11 	VT_FILETIME
			//Create Time/Date 	PID_CREATE_DTM 	12 	VT_FILETIME
			//Last Save Time/Date 	PID_LASTSAVE_DTM 	13 	VT_FILETIME
			//Page Count 	PID_PAGECOUNT 	14 	VT_I4
			//Word Count 	PID_WORDCOUNT 	15 	VT_I4
			//Character Count 	PID_CHARCOUNT 	16 	VT_I4
			//Creating Application 	PID_APPNAME 	18 	VT_LPSTR
			//Security 	PID_SECURITY 	19 	VT_I4

			#endregion

			private static readonly PropertyInfo[] DefaultPropertySet = new PropertyInfo[]
				{
					new PropertyInfo("Codepage", 1, VT.I2, "The ANSI code page used for any strings that are stored in the summary information. Note that this is not the same code page for strings in the installation database. The Codepage Summary property is used to translate the strings in the summary information into Unicode when calling the Unicode API functions."),
					new PropertyInfo("Title", 2, VT.LPSTR, "Breifly describes the installer."),
					new PropertyInfo("Subject", 3, VT.LPSTR, "Describes what can be installed using the installer."),
					new PropertyInfo("Author", 4, VT.LPSTR, "The manufacturer of the installer"),
					new PropertyInfo("Keywords", 5, VT.LPSTR, "Keywords that permit the database file to be found in a keyword search"),
					new PropertyInfo("Comments", 6, VT.LPSTR, "Used to describe the general purpose of the installer."),
					new PropertyInfo("Template", 7, VT.LPSTR, "The platform and languages supported by the installer (syntax:[platform property][,platform property][,...];[language id][,language id][,...].)."),
					new PropertyInfo("Last Saved By ", 8, VT.LPSTR, "The installer sets the Last Saved by Summary Property to the value of the LogonUser property during an administrative installation."),
					new PropertyInfo("Revision Number ", 9, VT.LPSTR, "Unique identifier of the installer package. In patch packages authored for Windows Installer version 2.0 this can be followed by a list of patch code GUIDs for obsolete patches that are removed when this patch is applied. The patch codes are concatenated with no delimiters separating GUIDs in the list. Windows Installer version 3.0 can install these earlier package versions and remove the obsolete patches. Windows Installer version 3.0 ignores the list of obsolete patches in the Revision Number Summary property if there is sequencing information present in the MsiPatchSequence table."),
					new PropertyInfo("Last Printed", 11, VT.FILETIME, "The date and time during an administrative installation to record when the administrative image was created. For non-administrative installations this property is the same as the Create Time/Date Summary property."),
					new PropertyInfo("Create Time/Date", 12, VT.FILETIME, "When the installer database was created."),
					new PropertyInfo("Last Save Time/Date", 13, VT.FILETIME, "When the last time the installer database was modified. Each time a user changes an installation the value for this summary property is updated to the current system time/date at the time the installer database was saved. Initially the value for this summary property is set to null to indicate that no changes have yet been made."),
					new PropertyInfo("Page Count", 14, VT.I4, "The minimum installer version required. \r\nFor Windows Installer version 1.0, this property must be set to the integer 100. For 64-bit Windows Installer Packages, this property must be set to the integer 200. For a transform package, the Page Count Summary property contains minimum installer version required to process the transform. Set to the greater of the two Page Count Summary property values belonging to the databases used to generate the transform. Set to Null in patch packages.", "0x{0:x}"),
					new PropertyInfo("Word Count", 15, VT.I4, "Indicates the type of source file image.", "0x{0:x}"),
					new PropertyInfo("Character Count", 16, VT.I4, "Two 16-bit words. The upper word contains the \"transform validation flags\" (used to verify that a transform can be applied to the database). The lower word contains the \"transform error condition flags\" (used to flag the error conditions of a transform)."),
					new PropertyInfo("Creating Application", 18, VT.LPSTR, "The software used to author the installation."),
					new PropertyInfo("Security", 19, VT.I4, "Indicates if the package should be opened as read-only:\r\n 0: No restriction \r\n2:Read-only recommended\r\n 4: Read-only enforced")
				};

			private string _valueFormatString = "{0}";

			public static PropertyInfo[] GetPropertiesFromDatabase(Database msidb)
			{
				int[] standardIDs = new int[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 15, 16, 18, 19};

				ArrayList properties = new ArrayList();
				using (SummaryInformation summaryInfo = new SummaryInformation(msidb))
				{
					foreach (int propID in standardIDs)
					{
						bool failed = false;
						object propValue = null;
						try
						{
							propValue = summaryInfo.GetProperty(propID);
						}
						catch
						{
							failed = true;
						}
						if (!failed)
							properties.Add(new PropertyInfo(propID, propValue));
					}
				}
				return (PropertyInfo[]) properties.ToArray(typeof (PropertyInfo));
			}

			public static void InitListViewColumns(ListView lv)
			{
				lv.Columns.Add("Name", 200, HorizontalAlignment.Left);
				lv.Columns.Add("Value", 225, HorizontalAlignment.Left);
				lv.Columns.Add("ID", 60, HorizontalAlignment.Left);
				lv.Columns.Add("Type", 60, HorizontalAlignment.Left);
				lv.AllowColumnReorder = true;
			}

			private PropertyInfo(int id, object value)
			{
				_pid = id;
				_value = value;

				PropertyInfo prototype = GetPropertyInfoByID(id);
				if (prototype != null)
				{
					_name = prototype.Name;
					_propertyType = prototype._propertyType;
					_description = prototype.Description;
					_valueFormatString = prototype._valueFormatString;
					switch(_propertyType)
					{
						case VT.FILETIME:
							//everything is coming from wix as a string, need to submit patch to wix:
							// _value = DateTime.FromFileTime((long)_value);
							break;
						case VT.I2:
						case VT.I4:
							if (_value is string && _value != null && ((string)_value).Length > 0)
							{
								try
								{
									_value = int.Parse((string)_value);
								}
								catch (FormatException )
								{}
							}
							break;
					}
					
				}
				else
				{
					_name = "non-standard";
					_propertyType = VT.EMPTY;
					_description = "Unknown.";
				}
				InitListViewItem();
			}

			private PropertyInfo(string name, int pid, VT propertyType, string description)
				: this(name, pid, propertyType, description, "{0}")
			{
			}

			private PropertyInfo(string name, int pid, VT propertyType, string description, string valueFormatString)
			{
				_name = name;
				_pid = pid;
				_propertyType = propertyType;
				_description = description;
				_value = null;
				_valueFormatString = valueFormatString;
				InitListViewItem();
				
			}

			private void InitListViewItem()
			{
				this.Text = _name;
				this.SubItems.AddRange(new string[] {ValueString, Convert.ToString(_pid), Convert.ToString(_propertyType)});
			}

			/// <summary>
			/// Returns a <see cref="PropertyInfo"/> with the specified <see cref="PropertyInfo.ID"/> or null if the ID is unknown.
			/// </summary>
			public static PropertyInfo GetPropertyInfoByID(int id)
			{
				foreach (PropertyInfo info in DefaultPropertySet)
				{
					if (info.ID == id)
						return info;
				}
				return null;
			}

			public string Name
			{
				get { return _name; }
			}

			public int ID
			{
				get { return _pid; }
			}

			public string Description
			{
				get { return _description; }
			}

			public object Value
			{
				get { return _value; }
			}

			public string ValueFormatString
			{
				get { return _valueFormatString; }
			}

			public string ValueString
			{
				get
				{
					return string.Format(this.ValueFormatString, this.Value);
				}
			}

		}

		private enum VT : uint
		{
			EMPTY = 0,
			NULL = 1,
			I2 = 2,
			I4 = 3,
			LPSTR = 30,
			FILETIME = 0x40,
		}

	}
}