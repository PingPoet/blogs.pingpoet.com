' Scott Willeke - http://blogs.pingpoet.com/overflow - 2004 
Imports VBParser
Imports System.Text

Public Class TestForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        Me.ParseExpr(Me.txtInputExpr.Text)

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents treeView As System.Windows.Forms.TreeView
    Friend WithEvents grpOutput As System.Windows.Forms.GroupBox
    Friend WithEvents txtOutput As System.Windows.Forms.TextBox
    Friend WithEvents grpInputExpr As System.Windows.Forms.GroupBox
    Friend WithEvents btnParse As System.Windows.Forms.Button
    Friend WithEvents propertyGrid As System.Windows.Forms.PropertyGrid
    Friend WithEvents txtInputExpr As System.Windows.Forms.TextBox
    Friend WithEvents Splitter1 As System.Windows.Forms.Splitter
    Friend WithEvents pnlMain As System.Windows.Forms.Panel
    Friend WithEvents Splitter2 As System.Windows.Forms.Splitter
    Friend WithEvents lblInfo As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.treeView = New System.Windows.Forms.TreeView
        Me.propertyGrid = New System.Windows.Forms.PropertyGrid
        Me.grpOutput = New System.Windows.Forms.GroupBox
        Me.txtOutput = New System.Windows.Forms.TextBox
        Me.grpInputExpr = New System.Windows.Forms.GroupBox
        Me.lblInfo = New System.Windows.Forms.Label
        Me.txtInputExpr = New System.Windows.Forms.TextBox
        Me.btnParse = New System.Windows.Forms.Button
        Me.Splitter1 = New System.Windows.Forms.Splitter
        Me.pnlMain = New System.Windows.Forms.Panel
        Me.Splitter2 = New System.Windows.Forms.Splitter
        Me.grpOutput.SuspendLayout()
        Me.grpInputExpr.SuspendLayout()
        Me.pnlMain.SuspendLayout()
        Me.SuspendLayout()
        '
        'treeView
        '
        Me.treeView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.treeView.ImageIndex = -1
        Me.treeView.Location = New System.Drawing.Point(0, 0)
        Me.treeView.Name = "treeView"
        Me.treeView.SelectedImageIndex = -1
        Me.treeView.Size = New System.Drawing.Size(504, 301)
        Me.treeView.TabIndex = 9
        '
        'propertyGrid
        '
        Me.propertyGrid.CommandsVisibleIfAvailable = True
        Me.propertyGrid.Dock = System.Windows.Forms.DockStyle.Right
        Me.propertyGrid.HelpVisible = False
        Me.propertyGrid.LargeButtons = False
        Me.propertyGrid.LineColor = System.Drawing.SystemColors.ScrollBar
        Me.propertyGrid.Location = New System.Drawing.Point(312, 0)
        Me.propertyGrid.Name = "propertyGrid"
        Me.propertyGrid.PropertySort = System.Windows.Forms.PropertySort.Alphabetical
        Me.propertyGrid.Size = New System.Drawing.Size(192, 301)
        Me.propertyGrid.TabIndex = 7
        Me.propertyGrid.Text = "propertyGrid1"
        Me.propertyGrid.ToolbarVisible = False
        Me.propertyGrid.ViewBackColor = System.Drawing.SystemColors.Window
        Me.propertyGrid.ViewForeColor = System.Drawing.SystemColors.WindowText
        '
        'grpOutput
        '
        Me.grpOutput.Controls.Add(Me.txtOutput)
        Me.grpOutput.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.grpOutput.Location = New System.Drawing.Point(0, 366)
        Me.grpOutput.Name = "grpOutput"
        Me.grpOutput.Size = New System.Drawing.Size(504, 104)
        Me.grpOutput.TabIndex = 8
        Me.grpOutput.TabStop = False
        Me.grpOutput.Text = "Output:"
        '
        'txtOutput
        '
        Me.txtOutput.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtOutput.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtOutput.Location = New System.Drawing.Point(3, 18)
        Me.txtOutput.Multiline = True
        Me.txtOutput.Name = "txtOutput"
        Me.txtOutput.ReadOnly = True
        Me.txtOutput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtOutput.Size = New System.Drawing.Size(498, 83)
        Me.txtOutput.TabIndex = 3
        Me.txtOutput.Text = ""
        '
        'grpInputExpr
        '
        Me.grpInputExpr.Controls.Add(Me.lblInfo)
        Me.grpInputExpr.Controls.Add(Me.txtInputExpr)
        Me.grpInputExpr.Controls.Add(Me.btnParse)
        Me.grpInputExpr.Dock = System.Windows.Forms.DockStyle.Top
        Me.grpInputExpr.Location = New System.Drawing.Point(0, 0)
        Me.grpInputExpr.Name = "grpInputExpr"
        Me.grpInputExpr.Size = New System.Drawing.Size(504, 60)
        Me.grpInputExpr.TabIndex = 6
        Me.grpInputExpr.TabStop = False
        Me.grpInputExpr.Text = "Input Expr:"
        '
        'lblInfo
        '
        Me.lblInfo.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblInfo.AutoSize = True
        Me.lblInfo.BackColor = System.Drawing.SystemColors.Info
        Me.lblInfo.Font = New System.Drawing.Font("Lucida Sans", 8.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInfo.ForeColor = System.Drawing.SystemColors.InfoText
        Me.lblInfo.Location = New System.Drawing.Point(8, 42)
        Me.lblInfo.Name = "lblInfo"
        Me.lblInfo.Size = New System.Drawing.Size(314, 16)
        Me.lblInfo.TabIndex = 3
        Me.lblInfo.Text = "Hover the mouse over the Tree below or the textbox above"
        '
        'txtInputExpr
        '
        Me.txtInputExpr.AcceptsReturn = True
        Me.txtInputExpr.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtInputExpr.HideSelection = False
        Me.txtInputExpr.Location = New System.Drawing.Point(8, 16)
        Me.txtInputExpr.Name = "txtInputExpr"
        Me.txtInputExpr.Size = New System.Drawing.Size(416, 22)
        Me.txtInputExpr.TabIndex = 2
        Me.txtInputExpr.Text = "parsedExpr = parser.ParseExpression(scanner, errorList)"
        '
        'btnParse
        '
        Me.btnParse.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnParse.Location = New System.Drawing.Point(432, 18)
        Me.btnParse.Name = "btnParse"
        Me.btnParse.Size = New System.Drawing.Size(64, 23)
        Me.btnParse.TabIndex = 1
        Me.btnParse.Text = "Parse"
        '
        'Splitter1
        '
        Me.Splitter1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Splitter1.Location = New System.Drawing.Point(0, 361)
        Me.Splitter1.Name = "Splitter1"
        Me.Splitter1.Size = New System.Drawing.Size(504, 5)
        Me.Splitter1.TabIndex = 10
        Me.Splitter1.TabStop = False
        '
        'pnlMain
        '
        Me.pnlMain.Controls.Add(Me.Splitter2)
        Me.pnlMain.Controls.Add(Me.propertyGrid)
        Me.pnlMain.Controls.Add(Me.treeView)
        Me.pnlMain.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnlMain.Location = New System.Drawing.Point(0, 60)
        Me.pnlMain.Name = "pnlMain"
        Me.pnlMain.Size = New System.Drawing.Size(504, 301)
        Me.pnlMain.TabIndex = 11
        '
        'Splitter2
        '
        Me.Splitter2.Dock = System.Windows.Forms.DockStyle.Right
        Me.Splitter2.Location = New System.Drawing.Point(307, 0)
        Me.Splitter2.Name = "Splitter2"
        Me.Splitter2.Size = New System.Drawing.Size(5, 301)
        Me.Splitter2.TabIndex = 10
        Me.Splitter2.TabStop = False
        '
        'TestForm
        '
        Me.AcceptButton = Me.btnParse
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.ClientSize = New System.Drawing.Size(504, 470)
        Me.Controls.Add(Me.pnlMain)
        Me.Controls.Add(Me.Splitter1)
        Me.Controls.Add(Me.grpOutput)
        Me.Controls.Add(Me.grpInputExpr)
        Me.Font = New System.Drawing.Font("Lucida Sans", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "TestForm"
        Me.Text = "VBParser Inspector"
        Me.grpOutput.ResumeLayout(False)
        Me.grpInputExpr.ResumeLayout(False)
        Me.pnlMain.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private _parseTree As VBParser.Tree


    Private Sub ParseExpr(ByVal inputExpr As String)
        Dim errorList As ArrayList = New ArrayList
        Dim scanner As Scanner = New Scanner(inputExpr)
        Dim parser As Parser = New Parser

        Dim parsedExpr As Expression = parser.ParseExpression(scanner, errorList)

        Dim sbOutput As New StringBuilder

        sbOutput.Append("--- Parse Result ---").Append(vbNewLine)
        sbOutput.Append("Parsed: ").Append(inputExpr).Append(vbNewLine)
        For Each errStr As Object In errorList
            sbOutput.Append(errStr.ToString()).Append(vbNewLine)
        Next

        sbOutput.AppendFormat("Errors: {0}", errorList.Count).Append(vbNewLine)
        Me.txtOutput.AppendText(sbOutput.ToString())
        Me.txtOutput.Select(Me.txtOutput.Text.Length, 0)
        Me.txtOutput.ScrollToCaret()

        _parseTree = parsedExpr

        ShowParseTreeInTreeView()
        InspectObject(parsedExpr)


    End Sub

    Private Sub ShowParseTreeInTreeView()
        Me.treeView.Nodes.Clear()
        Me.treeView.Nodes.Add(ShowParseTreeHelper(_parseTree))
        Me.treeView.Select()
        Me.treeView.ExpandAll()

    End Sub

    Private Function ShowParseTreeHelper(ByVal tree As VBParser.Tree) As TreeNode
        Dim node As TreeNode = New TreeNode(tree.GetType.Name)
        node.Tag = tree

        For Each childTree As VBParser.Tree In tree.Children
            node.Nodes.Add(ShowParseTreeHelper(childTree))
        Next

        Return node
    End Function

    Private Sub btnParse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnParse.Click
        ParseExpr(Me.txtInputExpr.Text)
    End Sub

    ' When the mouse moves over a node in the treeview select it's assoiated text in the textbox
    Private Sub treeView_MouseMove(ByVal sender As System.Object, ByVal e As MouseEventArgs) Handles treeView.MouseMove
        If (_parseTree Is Nothing) Then Return

        Dim node As TreeNode = Me.treeView.GetNodeAt(e.X, e.Y)

        If node Is Nothing Then Return
        Me.propertyGrid.SelectedObject = node.Tag

        node.EnsureVisible()
        treeView.SelectedNode = node
        treeView.Update()


        Dim t As Tree = DirectCast(node.Tag, Tree)
        InspectObject(t)
        SelectTextForParseTree(t)

    End Sub


    ' When the mouse moves over the textbox select the associated Tree in the parse tree
    Private Sub txtInputExpr_MouseMove(ByVal sender As Object, ByVal e As MouseEventArgs) Handles txtInputExpr.MouseMove
        If (_parseTree Is Nothing) Then Return

        ' Find the character the mouse is over
        Dim charPos As Integer = TextBoxApiHelp.CharFromPos(Me.txtInputExpr, txtInputExpr.PointToClient(txtInputExpr.MousePosition))
        If (charPos > Me.txtInputExpr.Text.Length) Then Return
        Dim tree As Tree = TreeFromCharPos(_parseTree, charPos)


        If (tree Is Nothing) Then Return
        If (Me.treeView.Nodes.Count < 1) Then Return

        InspectObject(tree)

        ' Select the text associated with the expr the mouse is over
        SelectTextForParseTree(tree)

        ' find the item in the treeview:
        Dim node As TreeNode = FindTreeViewNodeForParseTreeNode(tree, Me.treeView.Nodes(0))

        If (node Is Nothing) Then Return

        node.EnsureVisible()
        Me.treeView.SelectedNode = node
    End Sub


    Private Sub SelectTextForParseTree(ByVal tree As VBParser.Tree)
        Me.txtInputExpr.Select(tree.Span.Start.Index, tree.Span.Finish.Index - tree.Span.Start.Index)
    End Sub


    ' Finds the Tree item in the parse tree that encapsulates the specified character position 
    Private Function TreeFromCharPos(ByVal tree As VBParser.Tree, ByVal charPos As Integer) As Tree

        Dim match As Tree = Nothing

        If (tree.Span.Start.Index <= charPos AndAlso tree.Span.Finish.Index >= charPos) Then
            match = tree
            ' found a match, we want the last (lowest item inthe tree match)
            For Each treeChild As VBParser.Tree In tree.Children

                Dim temp As Tree = TreeFromCharPos(treeChild, charPos)
                If (Not temp Is Nothing) Then
                    match = temp
                End If

            Next treeChild
        End If

        Return match
    End Function

    Private Function FindTreeViewNodeForParseTreeNode(ByVal tree As VBParser.Tree, ByVal tvNode As System.Windows.Forms.TreeNode) As System.Windows.Forms.TreeNode
        If (tvNode.Tag Is tree) Then Return tvNode

        Dim found As TreeNode = Nothing

        For Each tvChild As TreeNode In tvNode.Nodes
            found = FindTreeViewNodeForParseTreeNode(tree, tvChild)
            If (Not found Is Nothing) Then Return found
        Next tvChild

        Return Nothing

    End Function

    ' Inspects the specified object in the property grid
    Private Sub InspectObject(ByVal obj As Object)
        Me.propertyGrid.SelectedObject = obj
        Me.propertyGrid.Update()
    End Sub

End Class
