''' Derrived from  Steve McMahon's DragDropTextBox in the ImageListDragCS project.
Public Class TextBoxApiHelp

    Declare Auto Function SendMessageInt Lib "user32.dll" Alias "SendMessage" (ByVal hWnd As IntPtr, ByVal Msg As Integer, ByVal wParam As Integer, ByVal lParam As Integer) As Integer
    Private Const EM_LINEINDEX As Integer = &HBB
    Private Const EM_POSFROMCHAR As Integer = &HD6
    Private Const EM_CHARFROMPOS As Integer = &HD7

    ''' <summary>
    ''' Returns the index of the character under the specified 
    ''' point in the control, or the nearest character if there
    ''' is no character under the point.
    ''' </summary>
    ''' <param name="txt">The text box control to check.</param>
    ''' <param name="pt">The point to find the character for, 
    ''' specified relative to the client area of the text box.</param>
    ''' <returns></returns>
    Public Shared Function CharFromPos(ByVal txt As System.Windows.Forms.TextBox, ByVal pt As Point) As Integer
        ' Convert the point into a DWord with horizontal position
        ' in the loword and vertical position in the hiword:
        Dim xy As Integer = (pt.X And &HFFFF) + ((pt.Y And &HFFFF) << 16)

        ' Get the position from the text box.
        Dim res As Integer = SendMessageInt(txt.Handle, EM_CHARFROMPOS, 0, xy)
        ' the Platform SDK appears to be incorrect on this matter.
        ' the hiword is the line number and the loword is the index
        ' of the character on this line
        Dim lineNumber As Integer = ((res And &HFFFF) >> 16)
        Dim charIndex As Integer = (res And &HFFFF)


        ' Find the index of the first character on the line within 
        ' the control:
        Dim lineStartIndex As Integer = SendMessageInt(txt.Handle, EM_LINEINDEX, lineNumber, 0)
        ' Return the combined index:
        Return lineStartIndex + charIndex
    End Function
End Class
