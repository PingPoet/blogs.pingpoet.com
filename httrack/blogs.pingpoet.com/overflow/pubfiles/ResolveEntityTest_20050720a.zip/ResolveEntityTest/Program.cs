/*
Scott Willeke - 2005
http://scott.willeke.com
I consider this code to be in the public domain, just don't sue me if it's broken.
*/
using System;
using System.Collections;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Xml;
using System.Xml.Schema;

namespace ResolveEntityTest
{
	class Program
	{
		const string XhtmlStrict = "xhtml1-strict.dtd";
		const string XhtmlLat1 = "xhtml-lat1.ent";
		const string XhtmlSpecial = "xhtml-special.ent";
		const string XhtmlSymbol = "xhtml-symbol.ent";

		[STAThread]
		static void Main(string[] args)
		{
			const string filePath = "..\\..\\entitytest1.xml";
			//prepare the validating reader:
			XmlParserContext xhtmlContext = CreateXhtmlContext();
			XmlValidatingReader rdr = new XmlValidatingReader(File.OpenRead(filePath), XmlNodeType.Document, xhtmlContext);
			rdr.ValidationType = ValidationType.None;
			rdr.XmlResolver = CreateXhtmlResolver();
			// Now use the handy XmlDocument to get the content:
			XmlDocument doc = new XmlDocument();
			doc.Load(rdr);
			
			string expected, actual;

			expected = "Hello" + (char)160 + "World";
			actual = doc.SelectSingleNode("/xhtml:html/xhtml:p[@id='space']",CreateXhtmlNamespaceManager()).InnerText;
			Console.WriteLine(actual);
			Debug.Assert(expected == actual);
			
			expected = "pi:" + (char)0x03C0;
			actual = doc.SelectSingleNode("/xhtml:html/xhtml:p[@id='pi']",CreateXhtmlNamespaceManager()).InnerText;
			Console.WriteLine(actual);
			Debug.Assert(expected == actual);
			
			expected = "euro:" + (char)0x20AC;
			actual = doc.SelectSingleNode("/xhtml:html/xhtml:p[@id='euro']",CreateXhtmlNamespaceManager()).InnerText;
			Console.WriteLine(actual);
			Debug.Assert(expected == actual);

			rdr.Close();
			Console.ReadLine();
		}

		/// <summary>
		/// Initializes a <see cref="T:XmlParserContext"/> instance configured with the XHTML strict DTD as the default DTD for the content.
		/// </summary>
		private static XmlParserContext CreateXhtmlContext()
		{
			/* FYI: http://www.w3.org/TR/2000/REC-xhtml1-20000126/
			XHTML 1.0 DOCTYPE declaration for strict:
			<!DOCTYPE html 
				PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
				"DTD/xhtml1-strict.dtd">

			XHTML 1.0 namespace:
			http://www.w3.org/1999/xhtml
			*/
			XmlNameTable nt = new NameTable();
			XmlNamespaceManager nsmgr = new XmlNamespaceManager(nt);
			XmlParserContext context = new XmlParserContext(null, nsmgr, null, XmlSpace.None);
			context.DocTypeName = "html";
			context.PublicId = "-//W3C//DTD XHTML 1.0 Strict//EN";
			context.SystemId = "xhtml1-strict.dtd";
			return context;
		}
		/// <summary>
		/// Initializes a new <see cref="T:XmlNamespaceManager"/> with the default namespace set to XHTML.
		/// </summary>
		/// <remarks>NOTE: This is only used to simplify the XPath test expression above</remarks>
		private static XmlNamespaceManager CreateXhtmlNamespaceManager()
		{
			XmlNamespaceManager nsMgr = new XmlNamespaceManager(new NameTable());
			nsMgr.AddNamespace("xhtml", "http://www.w3.org/1999/xhtml");
			return nsMgr;
		}
		/// <summary>
		/// Helper method that returns a new initialized <see cref="T:XmlResolver"/> implementation.
		/// </summary>
		private static XmlResolver CreateXhtmlResolver()
		{
			KnownResourceXmlResolver resolver = new KnownResourceXmlResolver();
			resolver.AddResource(new Uri("urn:" + "-//W3C//DTD XHTML 1.0 Strict//EN"), typeof(Program), XhtmlStrict);
			resolver.AddResource(new Uri("urn:" + XhtmlStrict), typeof(Program), XhtmlStrict);
			resolver.AddResource(new Uri("urn:" + XhtmlLat1), typeof(Program), XhtmlLat1);
			resolver.AddResource(new Uri("urn:" + XhtmlSpecial), typeof(Program), XhtmlSpecial);
			resolver.AddResource(new Uri("urn:" + XhtmlSymbol), typeof(Program), XhtmlSymbol);
			return resolver;
		}

		/// <summary>
		/// Resolves a known and limited set of URIs and entities as local resources.
		/// </summary>
		internal sealed class KnownResourceXmlResolver : XmlResolver
		{		 
			private ArrayList _knownResources = new ArrayList();

			/// <summary>
			/// Initializes a new instance of the <see cref="T:KnownResourceXmlResolver"/> class.
			/// </summary>
			public KnownResourceXmlResolver()
			{
			}

			/// <summary>
			/// Adds the specified entity  resource to this resolver's list of known resources.
			/// </summary>
			/// <param name="xmlUri">The identifier for the XML resource. The XML resolver uses this for <see cref="M:XmlResolver.GetEntity"/> and <see cref="M:XmlResolver.GetResolveUri"/>.</param>
			/// <param name="resourceNamespaceType">The type to use to resolve the assembly resource's assembly and namespace.</param>
			/// <param name="resourceName">The name of the assembly resource.</param>
			public void AddResource(System.Uri xmlUri, Type resourceNamespaceType, string resourceName)
			{
				if (xmlUri == null)
					throw new ArgumentNullException("xmlUri");
				if (resourceNamespaceType == null)
					throw new ArgumentNullException("resourceNamespaceType");
				if (resourceName == null)
					throw new ArgumentNullException("resourceName");
				_knownResources.Add(new XmlResource(xmlUri, resourceNamespaceType, resourceName));
			}

			/// <summary>
			/// Not supported.
			/// </summary>
			public override System.Net.ICredentials Credentials
			{
				set
				{
					throw new NotSupportedException();
				}
			}

			/// <summary>
			/// Resolves entities using local resources if it is a known entity.
			/// </summary>
			public override object GetEntity(Uri absoluteUri, string role, Type ofObjectToReturn)
			{
				foreach (XmlResource resource in this._knownResources)
				{
					if (resource.XmlUri.Equals(absoluteUri))
					{
						Trace.WriteLine(string.Format("CustomXmlResolver.GetEntity: '{0}' stream returned succsfully.", absoluteUri.ToString()));
						return resource.GetResourceStream();
					}
				}
				Trace.WriteLine(string.Format("CustomXmlResolver.GetEntity: '{0}' no entity available!", absoluteUri.ToString()));
				//TODO: REVIEW: Which to use, base or null ?
				return null;//return base.GetEntity(absoluteUri, role, ofObjectToReturn);
			}

			/// <summary>
			/// Resolves known URIs to known local resource URIs.
			/// </summary>
			public override Uri ResolveUri(Uri baseUri, string relativeUri)
			{
				foreach (XmlResource resource in this._knownResources)
				{
					//TODO: REVIEW: EndsWith is propably not suitable here. We should probably check the full string or "system ID"
					Uri relUri = new Uri("urn:" + relativeUri);
					if (resource.XmlUri.AbsolutePath.EndsWith(relUri.AbsolutePath))
					{
						Trace.WriteLine(string.Format("CustomXmlResolver.ResolveUri: '{0}' Resolved succsfully.", relativeUri));
						return resource.XmlUri;
					}
				}
				Trace.WriteLine(string.Format("CustomXmlResolver.ResolveUri: '{0}' UNRESOLVED.", relativeUri));
				//TODO: REVIEW: Which to use, base or null ?
				return null; //return base.ResolveUri (baseUri, relativeUri); 
			}
			
			/// <summary>
			/// Used internally to track xml entity resource info...
			/// </summary>
			private struct XmlResource
			{
				public System.Uri XmlUri;
				public Type NamespaceType;
				public string ResourceName;
				
				public XmlResource(System.Uri xmlUri, Type namespaceType, string resourceName)
				{
					this.XmlUri = xmlUri;
					this.NamespaceType = namespaceType;
					this.ResourceName = resourceName;
				}

				/// <summary>
				/// Returns the resource stream that this object describes.
				/// </summary>
				public Stream GetResourceStream()
				{
					return this.NamespaceType.Assembly.GetManifestResourceStream(this.NamespaceType, this.ResourceName);
				}
			}
		}
	}
}